# SmartWasteBottleSorter

Most of waste generated due to human activities can be recycled. One of such categories is segregation of colored bottles.However there must be a categorical separation of the waste accumulated. The project represents the Automation and the categorical segregation of waste in the warehouse system to minimise the manual efforts being carried out by the humans in the sorting facility centers. The system so developed can sort the bottles according to their color for further processing for the sorting.  
